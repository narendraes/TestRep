# Requirements

## 1. Functional Requirements

### FR-1: Tier 1 Automatic Scoring (Forge)
- **FR-1.1** On issue **created**, compute Tier 1 score (0–40) if auto-score-on-create is enabled for the project.
- **FR-1.2** On issue **updated**, re-compute Tier 1 score only if one of the scored fields changed (Description, Acceptance Criteria, parent — changelog field `IssueParentAssociation`) and re-score-on-update is enabled.
- **FR-1.3** Persist per-rule pass/fail breakdown, total Tier 1 score, timestamp, and content hash to the issue entity property `backlogQuality`.
- **FR-1.4** Write the total score (T1, and T1+T2 once available) to the **app-owned** Forge custom field `Backlog Quality Score` (number, `readOnly: true`) via `POST /rest/api/3/app/field/value` — the only endpoint permitted to write app-owned field values.
- **FR-1.5** Skip scoring for excluded items — by default anything at hierarchy level -1 (sub-task level, detected via `issuetype.hierarchyLevel`, not by name) plus any admin-listed issue type names — and for projects where the app is disabled.

### FR-2: Tier 2 AI Scoring (Rovo, via Automation)
- **FR-2.1** When Tier 1 score crosses the configured floor (default 40 = all checks pass; configurable as % threshold), the app updates the score field, which a Jira Automation rule watches.
- **FR-2.2** The Automation rule invokes the Rovo agent only when: T1 score ≥ floor AND no AI score exists for the current content hash.
- **FR-2.3** The Rovo agent evaluates 4 semantic dimensions (15 pts each, 0–60 total) per `03-SCORING-RUBRIC.md`.
- **FR-2.3b** The Rovo agent is defined in the same Forge app (`rovo:agent` module) with two Forge actions: `fetch-issue-context` (read) and `write-quality-review` (write). A separate Forge app is NOT used — app-owned field writes require the owning app.
- **FR-2.4** The agent posts a structured comment (fixed output contract) containing: total AI score, per-dimension score + one-line justification, top-3 improvement actions, suggested rewrite of Description and/or AC.
- **FR-2.5** The agent (or automation) updates `Backlog Quality Score` to T1 + T2 and stamps the AI score against the content hash so re-triggers are no-ops.
- **FR-2.6** The agent NEVER edits the Description or AC fields directly — suggestions only.

### FR-3: Issue Panel UI
- **FR-3.1** Display an issue panel showing: total score (X/100), Tier 1 breakdown as pass/fail rows with points, Tier 2 dimension scores when available, last-scored timestamp.
- **FR-3.2** Provide a "Re-score now" action that forces Tier 1 re-computation (bypasses hash check).
- **FR-3.3** Panel reads from the issue entity property (no backend invocation for display).

### FR-4: Project-Level Configuration
- **FR-4.1** A Project Settings page allows project admins to enable/disable: the app as a whole, auto-score on create, re-score on update, each Tier 1 rule individually, Rovo suggestion posting.
- **FR-4.2** Admins can adjust: Tier 1 rule weights (must sum ≤ 40), Tier 2 trigger floor, minimum description length, AC field ID, excluded issue types.
- **FR-4.3** Settings persist in Forge Storage keyed by project ID; unconfigured projects use hardcoded defaults.
- **FR-4.4** (Optional, v2) Global admin page to set org-wide defaults that projects can override.

### FR-4b: App-Owned Score Field
- **FR-4b.1** The score field is declared via `jira:customField` with `readOnly: true` — not editable by users, other apps, Automation, or external scripts. Only this app writes it.
- **FR-4b.2** The field uses a declarative `formatter` expression to render a colored badge + progress bar with zero function invocations, with `export: true` so the raw number remains available to JQL, reports, and CSV export.
- **FR-4b.3** Screen/issue-type scoping is performed by Jira admins using the field's context (projects + issue types) and screen assignments — the app documents this in its "Get started" docs but does not automate it.
- **FR-4b.4** All Tier 2 writes to the field flow through the app's `write-quality-review` Rovo action (same app), because no external principal can write an app-owned field.

### FR-5: Reporting / JQL
- **FR-5.1** The score custom field must be searchable via JQL (e.g., `"Backlog Quality Score" < 60`).
- **FR-5.2** (Optional, opt-in per project, v2) Weekly backlog-health job rolling scores up per Epic.

## 2. Non-Functional Requirements

- **NFR-1 Quota efficiency**: Manifest-level event filtering; hash short-circuit target < 100ms invocation for no-op updates; UI renders client-side from entity properties; no scheduled jobs by default; AI path consumes zero Forge invocations (runs via Automation + Rovo).
- **NFR-2 Idempotency**: Identical content never triggers duplicate scoring or duplicate AI comments (hash stamping at both tiers).
- **NFR-3 Latency**: Tier 1 score visible in panel within seconds of issue save.
- **NFR-4 Fail-safe**: Scoring failures must never block issue creation/editing; log and exit silently.
- **NFR-5 Permissions**: App requires only the scopes listed in `02-FORGE-APP-SPEC.md`; agent acts with app-level permission, not user impersonation, for writes.
- **NFR-6 Explainability**: Every point lost maps to a named rule/dimension visible to the user.

## 3. Out of Scope (v1)
- Direct field editing by the agent (accept-suggestion workflow) — v2 candidate.
- Duplicate detection across backlog, staleness flags, DoR sprint gate, dashboard — v2 candidates.
- Confluence integration.

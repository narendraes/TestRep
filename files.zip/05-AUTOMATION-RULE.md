# Jira Automation Rule — Tier 1 → Rovo Bridge

## Purpose
Invoke the Rovo agent for Tier 2 scoring automatically when Tier 1 passes its floor, with zero Forge quota cost and no re-trigger loops.

## Rule Definition (create per project, or one global rule scoped to projects with the app)

**Name:** `Backlog Quality — AI review (Rovo)`

**Trigger:**
- Field value changed → Field: `Backlog Quality Score`

**Conditions (all must match):**
1. `Backlog Quality Score` **≥ 40** *(or the project's floor; see note below)*
2. Issue is NOT at sub-task hierarchy level *(mirror the project's exclusions; avoid matching type names — they can be renamed)*
3. **AI-not-yet-scored guard** — smart-value condition on the entity property:
   ```
   {{issue.properties.backlogQuality.t2Score}} is empty
   OR
   {{issue.properties.backlogQuality.t2Hash}} does not equal {{issue.properties.backlogQuality.hash}}
   ```
   (Implement as an Advanced compare condition. This is the loop-breaker: after the agent
   stamps t2Hash = hash, the condition fails until content actually changes again.)

**Action:**
- **Invoke Rovo agent**: `Backlog Quality Auditor` — this is the Forge-defined agent shipped by the same app (`rovo:agent` module; instructions in `06-ROVO-AGENT-INSTRUCTIONS.md`). Automation invokes it like any other agent; its reads/writes happen through the app's Forge actions, which is the only legal write path to the app-owned score field.
- Pass context: issue key (`{{issue.key}}`).
- The agent performs its own reads (issue fields, parent Epic, entity property) and its own writes (structured comment + property/field update via its actions).

## Loop Safety Analysis
```
Forge writes score field (T1 only, t2 reset)      → rule fires
  → conditions pass (score ≥ floor, no AI stamp for hash)
  → Rovo scores, stamps t2Hash = hash, updates score field (T1+T2)
    → rule fires again (field changed)
    → condition 3 FAILS (t2Hash == hash)            → stop. ✔
Content edited later → Forge recomputes hash, resets t2 → cycle repeats correctly.
```
Also enable the rule option "Check to allow other rule actions to trigger this rule" **only if** the agent's field update comes through automation; the agent writes the field via the app's write-quality-review action (asApp), so default loop-detection settings suffice.

## Floor Note
The rule uses a static numeric floor. To respect per-project percent floors exactly, prefer the denormalized flag written by the Forge handler:
- Condition alternative: `{{issue.properties.backlogQuality.t2Eligible}} equals true`
- Handler sets `t2Eligible = (t1Score ≥ ceil(availableT1 * tier2TriggerPercent/100))`.
This keeps all threshold logic in one place (Forge) and makes the automation rule dumb and stable. **Recommended.**

## Failure Modes
| Failure | Behavior |
|---|---|
| Rovo agent errors / times out | No stamp written → next score-field change (or manual re-score) retries. |
| Agent posts comment but fails to stamp | Rule could re-fire on next field change → agent instruction includes "check for existing review comment for this hash before posting" as a secondary guard. |
| Rule disabled | System degrades gracefully to Tier 1-only scoring. |

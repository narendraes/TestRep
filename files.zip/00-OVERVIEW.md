# Backlog Quality Auditor — Forge App + Rovo Agent

## Purpose
A Jira Cloud app that continuously audits and improves backlog item quality using a two-tier scoring model:

- **Tier 1 (0–40 pts)** — Deterministic checks performed by a **Forge app** on issue create/update.
- **Tier 2 (0–60 pts)** — Semantic/AI checks performed by a **Rovo agent**, triggered automatically via Jira Automation once Tier 1 reaches a configurable floor.

Total quality score: **0–100**.

## High-Level Flow
```
Issue created/updated
        │
        ▼
[Forge trigger] ── field filter: fires only if Description / AC / IssueParentAssociation (parent) changed
        │
        ▼
[Hash short-circuit] ── if scored-field hash unchanged → exit immediately
        │
        ▼
[Tier 1 scoring: 0–40] ── writes score + breakdown to issue property + custom field
        │
        ▼  (score ≥ threshold, default 40)
[Jira Automation rule] ── condition: T1 score ≥ floor AND AI score not stamped for current hash
        │
        ▼
[Rovo agent] ── Tier 2 semantic scoring: 0–60
        │
        ▼
Writes AI score + breakdown + top-3 improvements + suggested rewrite as structured comment,
updates total score field. Loop closes (hash stamp prevents re-trigger spin).
```

## Components
| Component | Responsibility |
|---|---|
| Forge app (backend) | Tier 1 scoring, storage, triggers, app-owned score field writes |
| Forge app (UI Kit) | Issue panel (score breakdown), Project Settings page |
| App-owned custom field (jira:customField, readOnly) | Tamper-proof score display w/ declarative formatter (zero-invocation); admin-scoped to chosen screens/issue types via field context |
| Jira Automation rule | Bridge from Tier 1 completion → Rovo agent invocation |
| Rovo agent (defined IN the same Forge app via rovo:agent + action modules) | Tier 2 semantic scoring + improvement suggestions; writes via Forge actions running asApp |

## Design Principles
1. **Low Forge quota usage** — event filtering in manifest, hash short-circuits, client-side UI Kit rendering, no scheduled jobs by default, AI path fully outside Forge invocations.
2. **Project-level configurability** — every function can be enabled/disabled per project; hardcoded defaults apply when a project is unconfigured (zero setup friction).
3. **Deterministic before expensive** — AI scoring never runs until cheap structural checks pass.
4. **Explainability** — users always see *why* points were lost, per rule/dimension.
5. **Idempotency** — re-triggers on unchanged content are no-ops (hash stamping at both tiers).

## File Map (this spec set)
| File | Contents |
|---|---|
| `01-REQUIREMENTS.md` | Functional + non-functional requirements |
| `02-FORGE-APP-SPEC.md` | Manifest outline, modules, triggers, storage model, resolvers |
| `03-SCORING-RUBRIC.md` | Full Tier 1 + Tier 2 rubric with point anchors |
| `04-CONFIG-SPEC.md` | Project settings schema, defaults, UI spec |
| `05-AUTOMATION-RULE.md` | Jira Automation rule definition bridging Forge → Rovo |
| `06-ROVO-AGENT-INSTRUCTIONS.md` | Verbatim agent instruction text (paste into agent definition) |
| `07-CUSTOM-FIELD-UX.md` | 3-dot quality indicator: visual design, color logic, hover tooltips, manifest changes |

## Assumptions & Platform Facts (verified against Atlassian docs, Aug 2026)
- "Acceptance Criteria" is a custom field (configurable field ID per project; see `04-CONFIG-SPEC.md`).
- AC format standard is **Gherkin (Given/When/Then)**.
- Rovo is enabled on the Jira Cloud site and Jira Automation supports the Rovo agent action.
- Issue types in scope by default: hierarchy level 0 (Story/Task/Bug) and level 1 (Epic-level). Sub-tasks (level -1) excluded by default.

### ⚠️ Parent field — NOT "Epic Link"
- The `Epic Link` and `Parent Link` custom fields are **fully removed** from Jira Cloud REST APIs (removal completed Sept 2025) and were removed from webhooks/changelogs earlier. The **`parent` field** is the only supported parent association. Never reference `Epic Link`, `Parent Link`, or their custom field IDs anywhere in code.
- In event changelogs, reparenting appears as field **`IssueParentAssociation`** — not "Epic Link" or "Parent".
- Do NOT use issue links to infer parent/child relationships.

### ⚠️ Flexible hierarchy naming — never hardcode "Epic"
- The level-1 hierarchy level can be **renamed** per site (e.g., "Feature") and can contain **multiple issue types**. Premium/Enterprise sites can add levels **above** level 1 (Initiative, etc.).
- Therefore all logic keys off **`issuetype.hierarchyLevel`** (`-1` sub-task, `0` base, `1` epic-level, `>1` above-epic), never off the issue type *name*.
- "Epic" in these spec files means "**the issue's parent at hierarchy level ≥ 1**" / "**a level-1+ item**". UI copy should say "parent" or fetch the site's actual level name where display matters.

## Verified Documentation References
| Topic | Source |
|---|---|
| Epic Link / Parent Link removal from REST APIs (June/Sept 2025) | Atlassian Community: "The fields Epic Link and Parent Link will be removed" + ScriptRunner deprecation notes |
| Changelog field `IssueParentAssociation` replaces Epic Link/Parent values | developer.atlassian.com — Deprecation notice: issue reparenting changelogs |
| `parent.issuetype.hierarchyLevel` (-1 / 0 / 1) for parent type detection | Atlassian Developer Community — Epic Link deprecation thread (Atlassian staff answer) |
| Flexible naming of the Epic level; multiple types at level 1; extra levels above (Premium) | Atlassian Community: "Beyond epics: Flexible naming has landed" + support docs "Configure the work type hierarchy" |
| Issue links no longer used for parent relationships | developer.atlassian.com — Deprecation notice: hierarchy levels on issues |
| Forge `avi:jira:updated:issue` changelog payload | developer.atlassian.com — Forge events reference (Jira) |
| App-owned custom field write endpoint (`/rest/api/3/app/field/value`); only owning app may write | developer.atlassian.com — Issue custom field values (apps) REST API |
| `jira:customField` module: readOnly, formatter expression, view/experience | developer.atlassian.com — Jira custom field module reference |
| `rovo:agent` + `action` Forge modules (agents defined in Forge apps, actions as Forge functions) | developer.atlassian.com — Rovo modules / Rovo Agent / Action references |

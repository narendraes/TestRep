# Scoring Rubric (0–100)

## Tier 1 — Forge Deterministic Checks (0–40)

Default weights below; each rule individually toggleable and re-weightable per project (weights must sum ≤ 40). All checks are pure functions of issue field content — no AI.

| Rule ID | Check | Pts | Logic |
|---|---|---|---|
| `DESC_PRESENT` | Description present & meaningful length | 10 | Strip markup/whitespace; length ≥ `minDescriptionLength` (default 120 chars). ADF: concatenate text nodes. |
| `AC_PRESENT` | Acceptance criteria field populated | 10 | AC field (config `acFieldId`) non-empty after strip; length ≥ 40 chars. |
| `PARENT_CONTEXT` | Parent linkage with substance | 10 | Level-0 issues (Story/Task/Bug): `parent` field present with `parent.issuetype.hierarchyLevel ≥ 1` AND the parent's description non-empty (≥ 80 chars). Level-1+ issues (Epic-level, whatever the site calls it): award if own description ≥ 200 chars. Uses the `parent` field ONLY — Epic Link is removed from the API. Never test issue type by name; use `hierarchyLevel`. |
| `GHERKIN_KEYS` | AC structurally Gherkin-like | 5 | Case-insensitive regex: at least one complete triad — `\bgiven\b[\s\S]*?\bwhen\b[\s\S]*?\bthen\b`. Cheap structural gate before AI review. |
| `HYGIENE` | Basic hygiene | 5 | At least 2 of 3 present: component(s), label(s), estimate (story points or time). |

**Scoring notes**
- Partial credit: none at Tier 1 — each rule is binary pass/fail (keeps it explainable and deterministic).
- Bugs: `PARENT_CONTEXT` may be toggled off per project (bugs often legitimately un-parented); when a rule is disabled its points are unavailable and the Tier 2 floor should be set as a % (see `04-CONFIG-SPEC.md`).

## Tier 2 Trigger Floor
Default: Tier 2 fires when `t1Score ≥ 40` (all enabled rules pass). Configurable as a percentage of *available* Tier 1 points (default 100%), so disabling rules doesn't make the floor unreachable.

## Tier 2 — Rovo Semantic Checks (0–60)

Four dimensions × 15 pts. **Anchored bands are mandatory** — they are what keeps LLM scoring consistent across runs. The agent must justify each dimension score in one line referencing the band.

### D1 — Description Quality (0–15)
| Band | Pts | Anchor |
|---|---|---|
| Poor | 0–5 | Vague or placeholder text; no user/actor or goal identifiable; a reader could not start work without a conversation. |
| Fair | 6–10 | Actor and goal identifiable (user-story framing or equivalent), but missing context, rationale ("why"), or containing ambiguous terms ("fast", "user-friendly", "etc."). |
| Good | 11–15 | Clear actor, goal, and value; sufficient context to implement; no ambiguous or unresolved terms; scoped to a single deliverable. |

### D2 — AC ↔ Description Traceability (0–15)
| Band | Pts | Anchor |
|---|---|---|
| Poor | 0–5 | AC untestable, generic ("works as expected"), or covers behaviors not present in the description. |
| Fair | 6–10 | Most criteria map to stated behaviors, but at least one described behavior lacks a criterion, or at least one criterion has no basis in the description. |
| Good | 11–15 | Every criterion maps to a behavior stated in the description AND every testable behavior in the description has at least one criterion. Bidirectional coverage. |

### D3 — Epic Alignment / Inheritance (0–15)
*Applies to parented Story/Task/Bug. For Epics, replace with "Epic goal clarity" (does the Epic state an outcome, scope boundary, and success measure?).*
| Band | Pts | Anchor |
|---|---|---|
| Poor | 0–5 | Story contradicts, or is unrelated to, the parent Epic's stated goal/scope; or Epic description too thin to judge (cap at 5 and say so). |
| Fair | 6–10 | Story plausibly fits the Epic but the connection is implicit; contributes to the Epic without referencing its constraints/terminology. |
| Good | 11–15 | Story explicitly advances the Epic's goal, stays inside its scope boundaries, and is consistent with the Epic's constraints and terminology. |

### D4 — Gherkin Correctness (0–15)
*Beyond keyword presence (already Tier 1) — judges scenario quality.*
| Band | Pts | Anchor |
|---|---|---|
| Poor | 0–5 | Keywords present but misused: Given contains actions, Then is unobservable, or a single scenario bundles multiple behaviors. |
| Fair | 6–10 | Scenarios mostly well-formed; minor issues such as one compound Then, a missing edge/negative case, or one non-atomic scenario. |
| Good | 11–15 | Each scenario atomic (one behavior), Given = pure context, When = single action, Then = observable/verifiable outcome; happy path plus at least one edge or negative scenario where applicable. |

## Total Score Interpretation (panel color bands, configurable)
| Range | Meaning | Lozenge |
|---|---|---|
| 0–39 | Not ready — fails structural basics | Red |
| 40–69 | Structurally complete, needs semantic improvement | Yellow |
| 70–89 | Sprint-ready | Green |
| 90–100 | Exemplary — usable as a reference example | Green (bold) |

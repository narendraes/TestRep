# Custom Field Look & Feel — 3-Dot Quality Indicator

## 1. Why this changes the field's module type

The original design (`02-FORGE-APP-SPEC.md`) used `jira:customField` with a declarative `formatter` — cheap, zero-invocation, but **plain text only**. It cannot render colored dots or a hover tooltip.

To get interactive rendering, the field must be declared via **`jira:customFieldType`** instead, which supports a `function` property returning a real UI Kit component (`CustomField`) for the Issue View, in addition to keeping `formatter` as the fallback for List View, CSV export, and email notifications (per Atlassian docs, those surfaces never render the `function` — only `formatter`).

**Everything else about the field is unchanged:** still app-owned, still `readOnly: true`, still a single `number` (0–100) as the stored value for JQL/export — the 3-dot view is a presentation layer on top, computed from data already sitting in the `backlogQuality` entity property.

> **Verify at build time:** `readOnly` behavior and app-owned write exclusivity are confirmed for `jira:customField`; confirm they carry over identically for `jira:customFieldType`-derived fields before relying on it.

## 2. Segment Definition

| Dot | Label | Source (from `backlogQuality.t1Breakdown` / `t2Breakdown`) | Max Pts |
|---|---|---|---|
| **1** | Deterministic | Sum of Tier 1 rule points | 40 (or `availableT1` if rules disabled per project) |
| **2** | Description Quality & Traceability | D1 (Description Quality) + D2 (AC Traceability) | 30 |
| **3** | Inheritance & AC Coverage | D3 (Parent/Epic Alignment) + D4 (Gherkin Correctness) | 30 |

Total: 40 + 30 + 30 = **100**, identical to the existing overall score — this is a new *view* of the same numbers, not a new scoring model.

## 3. Color Logic (RAG)

Applied identically to all three dots, as a percentage of that dot's own max:

| Color | Threshold | Meaning |
|---|---|---|
| 🔴 Red | < 50% | Needs significant work |
| 🟡 Yellow | 50–79% | Partial, improvable |
| 🟢 Green | ≥ 80% | Strong |
| ⚪ Grey | *(dots 2 & 3 only)* Tier 2 has not run yet | Not yet evaluated — **not** a failure state |

Thresholds are configurable per project (see §6, extends `04-CONFIG-SPEC.md`). Default 50/80 mirrors the existing color-band convention already used for the overall score.

**Why grey matters:** an item that has just passed Tier 1 and is waiting on the Automation → Rovo hop would otherwise show two red dots it hasn't earned yet. Grey signals "pending," not "poor."

## 4. Hover Tooltip Content

Built entirely from data already in `backlogQuality` — **no rescoring, no additional Jira API calls beyond the one property read needed to render at all.**

**Dot 1 (Deterministic):**
- If `t1Score == availableT1`: `"All structural checks passed (40/40)"`
- Else: one line per **failed** rule only — e.g. `"Missing: Parent (epic-level) linked & described (0/10)"`, `"Missing: AC contains Given/When/Then (0/5)"`. Passed rules are omitted from the tooltip to keep it scannable — it's a punch list, not a report card.

**Dot 2 (Description Quality & Traceability):**
- If `t2Score == null`: `"AI review pending — runs automatically once Tier 1 passes"`
- Else: `"Description Quality: {D1}/15 — {D1 justification}"` and `"AC Traceability: {D2}/15 — {D2 justification}"`, one line each, justification text pulled verbatim from `t2Breakdown` (the same text already in the agent's review comment).

**Dot 3 (Inheritance & AC Coverage):**
- Same pattern using D3 and D4.

## 5. Layout

**Issue View (full rendering via `function`):**
```
●  ●  ●    72/100
```
Three small filled circles, ~10px, inline, each independently wrapped in a `Tooltip`; the total score as plain text alongside. No labels under the dots in the compact view — the tooltip carries the detail; a legend row ("Deterministic · Description & Traceability · Inheritance & Coverage") can sit as static help text once, e.g. in the field's description, rather than repeated per-issue.

**List View / Navigator / CSV / email (formatter fallback, zero-invocation, plain text only):**
```
🟢🟡⚪ 72/100
```
Colored-square emoji substitute for dots (plain text, no hover) — degrades gracefully rather than disappearing.

## 6. Illustrative Component Sketch (verify exact `@forge/react` API at build time)

```jsx
import { CustomField, Inline, Box, Text, Tooltip, Spinner, xcss } from '@forge/react';
import { useEffect, useState } from 'react';
import { invoke } from '@forge/bridge';

const dotStyle = (bgToken) => xcss({
  width: '10px',
  height: '10px',
  borderRadius: 'border.radius.circle',
  backgroundColor: bgToken,
});

function colorToken(pts, max, hasScore) {
  if (!hasScore) return 'color.background.neutral';           // grey
  const pct = pts / max;
  if (pct >= 0.8) return 'color.background.success.bold';     // green
  if (pct >= 0.5) return 'color.background.warning.bold';     // yellow
  return 'color.background.danger.bold';                      // red
}

function tier1Tooltip(t1Breakdown, available) {
  const failed = t1Breakdown.filter(r => !r.passed);
  if (failed.length === 0) return `All structural checks passed (${available}/${available})`;
  return failed.map(r => `Missing: ${r.label} (0/${r.maxPoints})`).join('\n');
}

function pairTooltip(t2Breakdown, indices) {
  if (!t2Breakdown) return 'AI review pending — runs automatically once Tier 1 passes';
  return indices
    .map(i => `${t2Breakdown[i].dimension}: ${t2Breakdown[i].score}/15 — ${t2Breakdown[i].justification}`)
    .join('\n');
}

const App = () => {
  const [quality, setQuality] = useState(null);

  useEffect(() => {
    // Reads the already-computed entity property — no rescoring.
    invoke('fetchQualityForField').then(setQuality);
  }, []);

  if (!quality) return <CustomField><Spinner /></CustomField>;

  const { t1Score, availableT1, t1Breakdown, t2Score, t2Breakdown } = quality;
  const dot2Score = t2Breakdown ? t2Breakdown[0].score + t2Breakdown[1].score : null;
  const dot3Score = t2Breakdown ? t2Breakdown[2].score + t2Breakdown[3].score : null;

  return (
    <CustomField>
      <Inline space="space.100" alignBlock="center">
        <Tooltip content={tier1Tooltip(t1Breakdown, availableT1)}>
          <Box xcss={dotStyle(colorToken(t1Score, availableT1, true))} />
        </Tooltip>
        <Tooltip content={pairTooltip(t2Breakdown, [0, 1])}>
          <Box xcss={dotStyle(colorToken(dot2Score ?? 0, 30, dot2Score != null))} />
        </Tooltip>
        <Tooltip content={pairTooltip(t2Breakdown, [2, 3])}>
          <Box xcss={dotStyle(colorToken(dot3Score ?? 0, 30, dot3Score != null))} />
        </Tooltip>
        <Text>{t1Score + (t2Score ?? 0)}/100</Text>
      </Inline>
    </CustomField>
  );
};
```

`fetchQualityForField` is a small resolver/action that reads the issue's `backlogQuality` entity property for the current `extensionContext.issueId` — one lightweight GET, no computation.

## 7. Quota Impact — Honest Trade-off

This is a deliberate departure from the original "zero-invocation display" goal in `01-REQUIREMENTS.md` (NFR-1), and worth calling out explicitly:

| | Original (`formatter`-only) | New (`function` + `formatter` fallback) |
|---|---|---|
| Issue View render cost | 0 invocations (client-side formatter) | 1 Forge invocation + 1 lightweight entity-property GET, per render |
| List View / CSV / email | 0 invocations (formatter) | Unchanged — still 0 (formatter fallback) |
| What's being read | N/A | Pre-computed JSON already sitting in `backlogQuality` — no rescoring, no external calls |

The added cost is bounded by **how often humans open the Issue View**, not by event volume (issue creates/updates) — a fundamentally smaller, human-paced quota surface, and each invocation is a trivial property read. This is considered an acceptable trade for the interactivity requested. If render volume ever becomes a concern, a short-lived cache (Forge Storage, keyed by `issueId:hash`, few-second TTL) can be added without changing the design.

## 8. Manifest Changes (supersedes the `jira:customField` block in `02-FORGE-APP-SPEC.md` §1)

```yaml
  jira:customFieldType:
    - key: backlog-quality-score-type
      name: Backlog Quality Score
      description: App-managed quality score (0-100) with 3-dot breakdown. Read-only.
      dataType: number
      readOnly: true
      formatter:
        expression: >
          `${value >= 70 ? '🟢' : value >= 40 ? '🟡' : '🔴'} ${value}/100`
        export: true
      function: quality-field-view       # renders the 3-dot component (Issue View only)
      edit: none                          # readOnly — no edit UI needed
      # A Jira admin creates a field FROM this type after install, then scopes it
      # to projects/issue types/screens exactly as before (see 02-FORGE-APP-SPEC.md).

  function:
    - key: quality-field-view
      handler: index.qualityFieldView
    - key: fetchQualityForField
      handler: index.fetchQualityForField   # resolver backing the invoke() call in §6
```

> **Verify at build time:** whether `jira:customFieldType` requires the Jira admin to manually create a field instance post-install (typical for this module, unlike `jira:customField` which auto-provisions), and adjust the app's "Get started" onboarding docs accordingly.

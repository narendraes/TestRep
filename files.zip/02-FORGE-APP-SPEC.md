# Forge App Specification

## 1. Modules (manifest.yml outline)

```yaml
modules:
  trigger:
    - key: issue-created-trigger
      function: scoreIssueHandler
      events:
        - avi:jira:created:issue
    - key: issue-updated-trigger
      function: scoreIssueHandler
      events:
        - avi:jira:updated:issue
      # CRITICAL: filter to scored fields only — kills most wasted invocations
      # NOTE (verified vs Atlassian docs): reparenting appears in changelogs as
      # field 'IssueParentAssociation' — NOT 'Epic Link' / 'Parent Link' / 'parent'.
      # Those legacy fields are fully removed from APIs, webhooks, and changelogs.
      filter:
        expression: >
          event.changelog != null &&
          event.changelog.items.some(i =>
            i.fieldId == 'description' ||
            i.field == 'IssueParentAssociation' ||
            i.fieldId == '<AC_FIELD_ID>')   # resolve per-project AC field; see note below
        onError: IGNORE_AND_RUN   # if filter errors, run handler (handler re-checks cheaply)
      # Implementation task: log one real update/reparent event payload during dev and
      # confirm the exact field/fieldId strings on the target instance before finalizing.

  jira:issuePanel:
    - key: quality-score-panel
      resource: panel-ui
      render: native            # UI Kit latest — client-side render, no invocation for display
      title: Backlog Quality
      resolver:
        function: panelResolver # hit only on explicit actions (Re-score now)

  jira:projectSettingsPage:
    - key: quality-settings-page
      resource: settings-ui
      render: native
      title: Backlog Quality Auditor
      resolver:
        function: settingsResolver

  # App-owned, tamper-proof score field.
  # Only THIS app can write values (via /rest/api/3/app/field/value).
  # Users/other apps/Automation/external scripts CANNOT modify it.
  jira:customField:
    - key: backlog-quality-score
      name: Backlog Quality Score
      description: App-managed quality score (0-100). Read-only.
      type: number
      readOnly: true
      # Declarative formatter = rich display with ZERO invocations
      formatter:
        expression: >
          `${value >= 70 ? '🟢' : value >= 40 ? '🟡' : '🔴'} ${value}/100
           ${'▰'.repeat(Math.round(value/10)).padEnd(10,'▱')}`
        export: true          # raw number exported for JQL/reports/CSV
      view:
        experience:
          - issue-view
      # Screen/type scoping is NOT done here — after install, a Jira admin:
      #   1. Edits the field's CONTEXT → restrict to chosen projects + issue types
      #   2. Adds the field only to the desired SCREENS
      # This satisfies "only those screens for those issue types" with native admin config.

  # Rovo agent DEFINED IN THIS SAME APP (mandatory — see §1a)
  rovo:agent:
    - key: backlog-quality-auditor
      name: Backlog Quality Auditor
      description: Audits backlog item quality, scores semantics (0-60), suggests improvements.
      prompt: resource:agent-prompt   # full text in 06-ROVO-AGENT-INSTRUCTIONS.md
      conversationStarters:
        - Review the quality of this issue
        - Why did this issue score low?
      actions:
        - fetch-issue-context
        - write-quality-review

  action:
    - key: fetch-issue-context
      function: fetchIssueContextFn
      actionVerb: GET
      description: >
        Fetches the issue's summary, description, acceptance criteria, hierarchy level,
        parent (level >= 1) summary/description, project config flags, and the
        backlogQuality entity property (incl. current content hash).
    - key: write-quality-review
      function: writeQualityReviewFn
      actionVerb: CREATE
      description: >
        Persists the AI review - posts the structured review comment, updates the
        backlogQuality entity property (t2Score, t2Breakdown, t2Hash), and writes
        the total score to the app-owned Backlog Quality Score field via
        /rest/api/3/app/field/value. Runs asApp - the ONLY legal write path
        for the app-owned field.

  function:
    - key: scoreIssueHandler
      handler: index.scoreIssue
    - key: panelResolver
      handler: index.panelResolver
    - key: settingsResolver
      handler: index.settingsResolver
    - key: fetchIssueContextFn
      handler: index.fetchIssueContext
    - key: writeQualityReviewFn
      handler: index.writeQualityReview

permissions:
  scopes:
    - read:jira-work
    - write:jira-work
    - storage:app
```

> **Note on AC field in filter:** manifest filters are static, so use the org-default AC field ID in the filter expression and re-verify per-project config inside the handler. If AC field IDs vary widely across projects, broaden the filter to description/parent and let the hash short-circuit absorb the rest.

## 1a. ONE Forge App, Not Two — Architectural Constraint (verified)

**Decision: the custom field AND the Rovo agent live in the same Forge app.** This is not a preference — it's forced by field ownership:

- Values of an app-owned custom field can only be updated **by the app that owns it**, through `POST /rest/api/3/app/field/value` (issue-edit API rejects it; other apps, Automation actions, and external scripts are all rejected).
- Therefore the Rovo agent's "write score" step MUST execute as this app. Forge supports exactly this: the agent is declared with the `rovo:agent` module and its writes are implemented as `action` modules — Forge functions running `asApp()`.
- Bonus benefits of one app: the agent's actions can read project config **directly from Forge Storage** (the earlier denormalization workaround becomes optional), one install, one permission grant, shared entity-property code.

Consequences for the write path:
```
Tier 1: scoreIssueHandler ──asApp──▶ POST /rest/api/3/app/field/value   (T1 score)
Tier 2: Rovo agent ──▶ write-quality-review action ──asApp──▶ same endpoint (T1+T2)
```
A regular `PUT /rest/api/3/issue/{key}` with this field in the payload will FAIL — always use the app-field-value endpoint. Include the `write:app-data:jira` scope if/when Atlassian makes it mandatory for this endpoint (currently optional per docs — verify at build time).

**Field display ("why is the score X?"):** the formatter shows the compact badge; the *why* lives in the issue panel (Tier 1 rows + Tier 2 dimensions from the entity property) and the agent's review comment. Don't overload the field itself — number type keeps JQL simple.

## 2. Handler Logic — `scoreIssue`

```
1. Extract projectId, issueId, issueType from event.
2. Load config: storage.get(`config:${projectId}`) ?? DEFAULTS   (see 04-CONFIG-SPEC.md)
3. Guards (exit fast, in order):
   a. config.enabled == false → exit
   b. issuetype.hierarchyLevel == -1 && config.excludeSubtaskLevel → exit; issueType.name in config.excludedIssueTypes → exit
   c. event is create && !config.autoScoreOnCreate → exit
   d. event is update && !config.rescoreOnUpdate → exit
4. Fetch issue fields in ONE call:
   GET /rest/api/3/issue/{key}?fields=description,issuetype,parent,{acFieldId},components,labels,{estimateField}
   - Parent association: use the `parent` field ONLY (legacy Epic Link / Parent Link
     fields are removed from the API). `parent` returns key + issuetype incl.
     `issuetype.hierarchyLevel`.
   - Determine level of THIS issue via `fields.issuetype.hierarchyLevel`
     (-1 sub-task, 0 base, 1 epic-level, >1 above-epic on Premium hierarchies).
   - If hierarchyLevel == 0 and `parent` is present with
     parent.issuetype.hierarchyLevel >= 1: fetch the parent's description
     (1 extra GET /rest/api/3/issue/{parentKey}?fields=description,summary).
   - Never match issue type by NAME ("Epic") — the level-1 type may be renamed
     (e.g., "Feature") and multiple types can live at level 1.
5. Compute contentHash = sha256(description + '|' + ac + '|' + parentKey + '|' + parentDescPresent)
6. Read entity property `backlogQuality`. If property.hash == contentHash → EXIT (no-op, ~50ms).
7. Run Tier 1 rules (03-SCORING-RUBRIC.md §Tier 1) using config weights/toggles.
8. Write entity property `backlogQuality`:
   {
     hash, t1Score, t1Breakdown: [{ruleId, label, passed, points, maxPoints}],
     t2Score: <preserved if hash unchanged... else null>,
     t2Hash: <preserved/null>, scoredAt
   }
9. Update custom field Backlog Quality Score = t1Score + (t2Score ?? 0).
   (Content changed → t2 reset to null → field shows T1 only → Automation rule
    sees score ≥ floor with no AI stamp → Rovo re-scores. Loop is hash-safe.)
```

## 3. Entity Property Schema — `backlogQuality`

```json
{
  "hash": "sha256-hex",
  "t1Score": 35,
  "t1Breakdown": [
    { "ruleId": "DESC_PRESENT", "label": "Description present & ≥ min length", "passed": true,  "points": 10, "maxPoints": 10 },
    { "ruleId": "AC_PRESENT",   "label": "Acceptance criteria populated",       "passed": true,  "points": 10, "maxPoints": 10 },
    { "ruleId": "PARENT_CONTEXT", "label": "Parent (epic-level) linked & described", "passed": false, "points": 0, "maxPoints": 10 },
    { "ruleId": "GHERKIN_KEYS", "label": "AC contains Given/When/Then",         "passed": true,  "points": 5,  "maxPoints": 5 },
    { "ruleId": "HYGIENE",      "label": "Component/label/estimate present",    "passed": true,  "points": 5,  "maxPoints": 5 }
  ],
  "t2Score": null,
  "t2Hash": null,
  "t2Breakdown": null,
  "scoredAt": "2026-08-04T12:00:00Z"
}
```

Rovo agent (via its write action or automation) sets `t2Score`, `t2Hash` (= `hash` it scored), `t2Breakdown`.

## 4. Issue Panel (UI Kit, `panel-ui`)

- Reads `backlogQuality` entity property via the view context / a single lightweight resolver call on open (or `requestJira` from frontend where UI Kit allows) — display is cheap.
- Layout (keep minimal, no iframe custom UI):
  - **Header row**: `Score: 75 / 100` with colored Lozenge (red < 40, yellow 40–69, green ≥ 70; thresholds from config).
  - **Tier 1 section**: one row per rule → ✅/❌ icon, label, `pts/max`.
  - **Tier 2 section** (if `t2Score != null`): dimension rows with scores; link text "See AI review comment".
  - **Footer**: `Last scored <relative time>` + **Re-score now** button → resolver → runs handler with `forceRescore=true` (bypasses hash check only; all other guards apply).
- If property absent: show "Not yet scored" + Re-score now.

## 5. Settings Page (UI Kit, `settings-ui`)
See `04-CONFIG-SPEC.md` for the schema and UI layout. Resolver exposes `getConfig(projectId)` / `saveConfig(projectId, config)` with project-admin permission check.

## 6. Quota Budget (targets)
| Path | Invocations |
|---|---|
| Issue update not touching scored fields | 0 (manifest filter) |
| Update touching scored fields, content-identical | 1 short (~50ms hash exit) |
| Real content change | 1 full (2–3 Jira API GETs + 1–2 PUTs) |
| Panel open | 0–1 lightweight read |
| Tier 2 AI scoring | 0 Forge invocations (Automation + Rovo) |

## 7. Error Handling
- Wrap handler in try/catch; on failure log via console (Forge logs) and exit — never throw into the event pipeline.
- Jira API 429s: single retry with backoff, then abandon (next edit will re-trigger).
- Missing AC field on a project: treat AC rules as N/A, redistribute nothing — points simply not awarded; surface a config warning banner in Settings page.

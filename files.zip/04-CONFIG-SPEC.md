# Project-Level Configuration

## 1. Storage
- Key: `config:${projectId}` in Forge Storage (`storage:app` scope).
- Read path: `storage.get(key) ?? DEFAULTS` — **unconfigured projects silently use defaults** (zero setup friction).
- Save path: settings resolver validates then `storage.set(key)`. Only project admins may save (check via permissions API in resolver).
- A "Reset to defaults" action deletes the key.

## 2. Config Schema + Hardcoded Defaults

```typescript
interface ProjectConfig {
  enabled: boolean;                    // default: true  — master switch
  autoScoreOnCreate: boolean;          // default: true
  rescoreOnUpdate: boolean;            // default: true
  rovoSuggestionsEnabled: boolean;     // default: true  — agent posts rewrite suggestions
                                       //   (read by the Rovo agent via issue property / automation)

  acFieldId: string;                   // default: org-wide AC custom field id, e.g. "customfield_10057"
  minDescriptionLength: number;        // default: 120 (chars, markup-stripped)
  excludedIssueTypes: string[];        // default: [] — extra exclusions by type NAME (site-specific)
  excludeSubtaskLevel: boolean;        // default: true — excludes hierarchyLevel === -1
                                       //   (robust vs renaming; primary exclusion mechanism)

  tier1Rules: {
    DESC_PRESENT:  { enabled: boolean; weight: number };  // default: true, 10
    AC_PRESENT:    { enabled: boolean; weight: number };  // default: true, 10
    PARENT_CONTEXT: { enabled: boolean; weight: number };  // default: true, 10
    GHERKIN_KEYS:  { enabled: boolean; weight: number };  // default: true, 5
    HYGIENE:       { enabled: boolean; weight: number };  // default: true, 5
  };                                   // validation: sum of enabled weights ≤ 40

  tier2TriggerPercent: number;         // default: 100 — % of *available* T1 points required
                                       //   to fire Tier 2 (floor = ceil(availableT1 * pct/100))

  colorBands: { yellowFrom: number; greenFrom: number };  // default: 40 / 70 (overall score, used in issue panel)

  segmentThresholds: { yellowFromPct: number; greenFromPct: number };
  // default: 50 / 80 — RAG thresholds for the 3-dot custom field indicator
  // (07-CUSTOM-FIELD-UX.md), applied as a % of each dot's own max (40/30/30)
}
```

**Why a percent floor:** if a project disables `PARENT_CONTEXT` (e.g., for bugs), available T1 points become 30; a hard "40" floor would be unreachable. `100%` of available points preserves the "all structural checks pass before AI" semantics regardless of which rules are on.

## 3. Settings Page UI (UI Kit — keep it clean and flat)

```
Backlog Quality Auditor — Project Settings
──────────────────────────────────────────
[Toggle] Enable Backlog Quality Auditor for this project        (master)

Scoring triggers
  [Toggle] Score automatically when an issue is created
  [Toggle] Re-score when Description / AC / parent changes

Tier 1 rules                              weight
  [Toggle] Description present & length    [10 ▾]
  [Toggle] Acceptance criteria populated   [10 ▾]
  [Toggle] Parent (epic-level) with description [10 ▾]
  [Toggle] AC contains Given/When/Then     [ 5 ▾]
  [Toggle] Hygiene (component/label/est.)  [ 5 ▾]
  (inline validation: "Enabled weights sum to 40 / 40 max")

AI review (Rovo)
  [Toggle] Post AI improvement suggestions
  Tier 2 trigger threshold: [100]% of available Tier 1 points

Fields
  Acceptance Criteria field: [field picker ▾]     (warn if unset/not found)
  Minimum description length: [120] characters
  [Toggle] Exclude sub-task level (recommended)
  Additional excluded issue types: [multi-select ▾]

[Save]   [Reset to defaults]
```

- Use native UI Kit components only (Toggle, Textfield, Select, SectionMessage) — no custom iframe.
- Show a SectionMessage warning if `acFieldId` doesn't resolve on this project (AC rules will award 0).
- Validation errors block save with inline messages.

## 4. Config Consumption Map
| Consumer | Reads |
|---|---|
| `scoreIssue` handler | everything except colorBands |
| Issue panel | colorBands, enabled |
| Automation rule | indirectly — floor is enforced by handler stamping "t2Eligible" into the entity property (see 05) |
| Rovo agent | `rovoSuggestionsEnabled` (exposed via entity property `backlogQuality.suggestionsEnabled`, written by handler) |

> Implementation note: since Automation and Rovo can't call Forge Storage, the handler denormalizes whatever they need (eligibility flag, suggestions flag) into the issue entity property / score field at scoring time.
